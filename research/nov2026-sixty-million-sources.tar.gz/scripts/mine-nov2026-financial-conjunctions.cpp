// Exhaustively score every binary attribute conjunction of length 1..6
// across 24 pre-result attributes and each of six legal JRA bet markets.
// 6 * sum_{k=1}^6 C(24,k)*2^k == 60,969,792 real candidate predicates.
// Per-market zeta transform of *actual* 100-yen cash payout, not top-1 labels.
// Source input: raw records {uint32 bits, payoutYen, year, market}, native LE.
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <algorithm>
#include <stdexcept>

struct Record {uint32_t bits,payout,year,market;};
struct Rule {double score;uint32_t select,high;uint32_t tn,vn;uint64_t tp,vp;};
struct LowScoreFirst {bool operator()(Rule const& a,Rule const& b)const{return a.score>b.score;}};

static void zeta(std::vector<uint32_t>& n, std::vector<uint64_t>& cash, unsigned bits){
  const size_t size=1ULL<<bits;
  for(unsigned bit=0;bit<bits;++bit){
    size_t step=1ULL<<bit;
    for(size_t off=0;off<size;off+=2*step){
      uint32_t *n0=n.data()+off,*n1=n0+step;
      uint64_t *p0=cash.data()+off,*p1=p0+step;
      for(size_t j=0;j<step;++j){n0[j]+=n1[j];p0[j]+=p1[j];}
    }
  }
}
int main(int argc,char**argv){
 try{
  if(argc<4||argc>6)throw std::runtime_error("usage: miner INPUT market OUTPUT [bits=24] [depth=6]");
  const unsigned target=std::stoul(argv[2]);
  const unsigned bits=argc>4?std::stoul(argv[4]):24;
  const unsigned depth=argc>5?std::stoul(argv[5]):6;
  if(target>5||bits>24||bits<2||depth>6||depth>bits||depth<1)throw std::runtime_error("invalid market/bits/depth");
  const size_t total=1ULL<<bits;
  std::vector<uint32_t> tn(total,0),vn(total,0);
  std::vector<uint64_t> tp(total,0),vp(total,0);
  std::ifstream f(argv[1],std::ios::binary);
  if(!f)throw std::runtime_error("input not found");
  Record r;uint64_t read=0,pay=0,train=0,val=0;
  while(f.read(reinterpret_cast<char*>(&r),sizeof(r))){
    if(r.market!=target)continue;
    if(r.bits>=total)throw std::runtime_error("bad categorical ticket bits");
    if(r.year>=2017&&r.year<=2021){++tn[r.bits];tp[r.bits]+=r.payout;++train;}
    else if(r.year==2022){++vn[r.bits];vp[r.bits]+=r.payout;++val;}
    ++read;pay+=r.payout;
  }
  if(train<10000||val<1000)throw std::runtime_error("missing pre-2023 training sample");
  std::cerr<<"MARKET_RAW "<<target<<" trainTickets="<<train<<" validationTickets="<<val<<"\n";
  zeta(tn,tp,bits);zeta(vn,vp,bits);
  std::priority_queue<Rule,std::vector<Rule>,LowScoreFirst> best;
  constexpr size_t KEEP=2000;
  uint64_t examined=0,with_support=0,cash_positive=0;
  for(unsigned k=1;k<=depth;++k){
    uint32_t comb=(1u<<k)-1u;
    do{
      std::array<uint32_t,6> selected_bits{};
      unsigned i=0;
      for(unsigned b=0;b<bits;++b)if((comb>>b)&1u)selected_bits[i++]=1u<<b;
      unsigned configurations=1u<<k;
      std::array<uint32_t,64> pos{};
      std::array<int64_t,64> a{},b{},c{},d{};
      for(unsigned j=1;j<configurations;++j){
        unsigned bit=__builtin_ctz(j);
        pos[j]=pos[j^(1u<<bit)]|selected_bits[bit];
      }
      for(unsigned j=0;j<configurations;++j){
        a[j]=tn[pos[j]];b[j]=tp[pos[j]];
        c[j]=vn[pos[j]];d[j]=vp[pos[j]];
      }
      // Möbius inversion on the selected-feature cube gives EVERY low/high
      // assignment from the superset sums without scanning tickets again.
      for(unsigned bit=0;bit<k;++bit){
        for(unsigned j=0;j<configurations;++j){
          if(!(j&(1u<<bit))){
            a[j]-=a[j|(1u<<bit)];b[j]-=b[j|(1u<<bit)];
            c[j]-=c[j|(1u<<bit)];d[j]-=d[j|(1u<<bit)];
          }
        }
      }
      for(unsigned j=0;j<configurations;++j){
        ++examined;
        if(a[j]<0||b[j]<0||c[j]<0||d[j]<0)
          throw std::runtime_error("negative Mobius cash");
        if(a[j]<100||c[j]<20)continue;
        ++with_support;
        if(b[j]==0||d[j]==0)continue;
        ++cash_positive;
        const double tr=double(b[j])/(100.*a[j]);
        const double vr=double(d[j])/(100.*c[j]);
        // Reject fragile ratios through cash-only shrinkage, with 2022
        // used solely for pre-2023 selection. No 2023+ payments used.
        const double floor=std::min(tr,vr);
        const double combined=double(b[j]+d[j])/(100.*(a[j]+c[j]));
        const double support=std::sqrt(double(a[j])/(a[j]+250.)*double(c[j])/(c[j]+60.));
        const double score=(0.80*floor+0.20*combined)*support;
        if(best.size()<KEEP||score>best.top().score){
          best.push(Rule{score,comb,pos[j],uint32_t(a[j]),uint32_t(c[j]),uint64_t(b[j]),uint64_t(d[j])});
          if(best.size()>KEEP)best.pop();
        }
      }
      uint32_t lowest=comb&-comb;
      uint32_t next=comb+lowest;
      if(next>=total||next==0)break;
      comb=(((next^comb)>>2)/lowest)|next;
    }while(comb<total);
  }
  std::ofstream out(argv[3]);
  if(!out)throw std::runtime_error("can't write output");
  out<<"market,selectMask,highMask,score,trainTickets,trainPaidYen,validationTickets,validationPaidYen\n";
  std::vector<Rule> rows;
  while(!best.empty()){rows.push_back(best.top());best.pop();}
  std::sort(rows.begin(),rows.end(),[](auto const&a,auto const&b){return a.score>b.score;});
  for(auto const &x:rows){
    out<<target<<','<<x.select<<','<<x.high<<','<<std::setprecision(12)<<x.score<<','
       <<x.tn<<','<<x.tp<<','<<x.vn<<','<<x.vp<<'\n';
  }
  std::cout<<"FINANCIAL_CONJUNCTION_MINE {\"market\":"<<target
           <<",\"examined\":"<<examined<<",\"trainValidationSupported\":"<<with_support
           <<",\"positiveCashBoth\":"<<cash_positive<<",\"retained\":"<<rows.size()
           <<",\"topCashScore\":"<<(rows.empty()?0.:rows[0].score)<<"}"<<std::endl;
  return 0;
 }catch(std::exception const&e){std::cerr<<"FINANCIAL_MINER_FAIL "<<e.what()<<"\n";return 1;}
}
