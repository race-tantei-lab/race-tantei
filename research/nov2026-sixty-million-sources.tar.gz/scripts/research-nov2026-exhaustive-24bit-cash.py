#!/usr/bin/env python3
"""Read-only, >60m distinct pre-race conjunctions, actual paid JPY.

This does NOT relabel failed research as a model. Candidate rule search uses
2017-21 historical cash and 2022 cash for selection. The 2023-26JanApr
payouts settle an immutable portfolio, never select it. No JRA T15 snapshots.
"""
from __future__ import annotations
import csv,gzip,importlib.util,json,math,subprocess,sys,time
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
MINE=ROOT/'scripts/mine-nov2026-financial-conjunctions.cpp'
OUT=ROOT/'analysis-results/nov2026-millions-condition-cash-search.json'
BETS=ROOT/'analysis-results/nov2026-millions-condition-cash-bets.csv.gz'
RULES=ROOT/'analysis-results/nov2026-millions-condition-retained-rules.csv.gz'
BOUNDS=((0,7),(7,28),(28,49),(49,91),(91,126),(126,336))
CONTEXT=('venue','fieldSize','quarter','favOdds','oddsGeom')
DEPTH=6
TOPK=(50,250,1000,2000)
STAKES=(100,400,1600)
SCORE_MODES=('max','vote')
EXPECTED=6*sum(math.comb(24,k)*(2**k) for k in range(1,7))
assert EXPECTED==60969792

def load_data():
    fn=ROOT/'scripts/research-nov2026-seasonal-ensemble-cash-first.py'
    spec=importlib.util.spec_from_file_location('million_payout_source',fn)
    obj=importlib.util.module_from_spec(spec);sys.modules[spec.name]=obj
    spec.loader.exec_module(obj)
    return obj.obtain_rows(),obj

def source_codes(data):
    races,payout,cats,widths,types,rid,year,quarter,joint=data
    form=ROOT/'scripts/research-nov2026-chronological-form-money-conditions.py'
    spec=importlib.util.spec_from_file_location('million_cash_features',form)
    obj=importlib.util.module_from_spec(spec);sys.modules[spec.name]=obj
    spec.loader.exec_module(obj)
    features=[name for name in obj.NEW_NAMES if name!='rankFormMismatch']+list(CONTEXT)
    if len(features)!=24 or len(set(features))!=24:
        raise RuntimeError('EXPECTED_24_DISTINCT_NON_OUTCOME_FIELDS')
    n=len(races)
    encoded=np.zeros((n,336),dtype=np.uint32)
    values={}
    for bit,key in enumerate(features):
        arr=cats[key].reshape(n,336)
        if len(arr)!=n or key not in widths:raise RuntimeError('UNAVAILABLE_FEATURE_'+key)
        # Fixed pre-declared bin midpoint for all features; not optimized on
        # any evaluation payout. All four-category form features keep both tails.
        threshold=int(widths[key])//2
        encoded |= (arr>=threshold).astype(np.uint32)<<bit
        values[key]={'categories':int(widths[key]),'positiveWhenCategoryAtLeast':threshold}
    if int(encoded.max()) >=1<<24:raise RuntimeError('TOO_MANY_FEATURE_BITS')
    return features,encoded,values

def dump_matrix(data,encoded,path):
    races,payout,cats,widths,types,rid,year,quarter,joint=data
    n=len(races)
    market=np.array([0]*7+[1]*21+[2]*21+[3]*42+[4]*35+[5]*210,dtype=np.uint32)
    # Fixed endian and width, matching the C++ Record {uint32_t x 4}.
    mat=np.empty((n,336,4),dtype='<u4')
    mat[:,:,0]=encoded
    mat[:,:,1]=payout.reshape(n,336)
    mat[:,:,2]=year[:,None].astype(np.uint32)
    mat[:,:,3]=market[None,:]
    path.parent.mkdir(parents=True,exist_ok=True)
    mat.tofile(path)
    return int(mat.shape[0]*mat.shape[1])

def run_miner(path):
    exe=ROOT/'analysis-results/nov2026-financial-conjunction-miner'
    comp=subprocess.run(['g++','-std=c++17','-O3','-march=x86-64','-Wall','-Wextra',str(MINE),'-o',str(exe)],
                        capture_output=True,text=True,check=True)
    results=[];rows=[]
    for market in range(6):
        file=ROOT/f'analysis-results/nov2026-conjunction-market-{market}.csv'
        x=subprocess.run([str(exe),str(path),str(market),str(file),'24','6'],
                         capture_output=True,text=True,timeout=3600)
        if x.returncode!=0:
            raise RuntimeError('MINER_FAILED_MARKET_'+str(market)+'\n'+x.stderr[-3000:]+'\n'+x.stdout[-500:])
        line=next((line for line in x.stdout.splitlines() if line.startswith('FINANCIAL_CONJUNCTION_MINE ')),None)
        if not line:raise RuntimeError('MINER_NO_EXAMINED_CONDITIONS_'+str(market))
        summary=json.loads(line.split(' ',1)[1]);results.append(summary)
        with file.open(newline='') as f:
            rows.extend(dict(row) for row in csv.DictReader(f))
        print('FINANCIAL_CONJUNCTION_SEARCH_MARKET',json.dumps(summary),flush=True)
        file.unlink()
    examined=sum(x['examined'] for x in results)
    if examined !=EXPECTED:
        raise RuntimeError(f'INCOMPLETE_EXHAUSTIVE_COHORT_ENUMERATION:{examined}!={EXPECTED}')
    return results,rows

def metrics(rows):
    s=sum(x['stakeYen'] for x in rows)
    p=sum(x['paidYen'] for x in rows)
    peak=max((x['paidYen'] for x in rows),default=0)
    return {'races':len(rows),'tickets':2*len(rows),'spentYen':s,'paidYen':p,
            'cashRoiPct':round(100*p/s,5) if s else None,
            'minusLargestRaceCashRoiPct':round(100*(p-peak)/s,5) if s else None,
            'biggestPaidRaceYen':peak,
            'hitRacePct':round(100*sum(x['paidYen']>0 for x in rows)/len(rows),5) if rows else None}

def build_scores(encoded,index,rule_rows):
    # The retained shortlist is determined exclusively by 2017-22 cash.
    # Every 2023+ ticket is scored only from its pre-result known predicates.
    n=len(index)
    result={k:{mode:np.zeros((n,336),dtype=np.float32) for mode in SCORE_MODES} for k in TOPK}
    if n==0:return result
    for market,(lo,hi) in enumerate(BOUNDS):
        rules=[r for r in rule_rows if int(r['market'])==market]
        uniques,inverse=np.unique(encoded[index,lo:hi],return_inverse=True)
        maxscore=np.zeros(len(uniques),dtype=np.float32)
        votes=np.zeros(len(uniques),dtype=np.float32)
        for i,rule in enumerate(rules[:max(TOPK)]):
            sel=int(rule['selectMask']); high=int(rule['highMask'])
            weight=float(rule['score'])
            active=(uniques & sel)==high
            maxscore[active]=np.maximum(maxscore[active],weight)
            votes[active]+=min(weight,8.0)
            if i+1 in TOPK:
                k=i+1
                result[k]['max'][:,lo:hi]=maxscore[inverse].reshape(n,hi-lo)
                result[k]['vote'][:,lo:hi]=np.log1p(votes[inverse]).reshape(n,hi-lo)
        # The absence of a qualifying rule creates a zero-score fallback;
        # it does not erase a race from coverage or invent a cash gain.
        for k in TOPK:
            if len(rules)<k:
                result[k]['max'][:,lo:hi]=maxscore[inverse].reshape(n,hi-lo)
                result[k]['vote'][:,lo:hi]=np.log1p(votes[inverse]).reshape(n,hi-lo)
    return result

def make_bets(data,period_index,score,second_yen):
    races,payout,_,_,_,_,year,quarter,_=data
    cash=payout.reshape(len(races),336)
    days=defaultdict(list)
    for j,idx in enumerate(period_index):
        i=int(idx)
        by_market=[]
        for market,(lo,hi) in enumerate(BOUNDS):
            pos=lo+int(np.argmax(score[j,lo:hi]))
            by_market.append((float(score[j,pos]),market,pos))
        first,second=sorted(by_market,key=lambda item:(-item[0],item[1]))[:2]
        assert first[1]!=second[1]
        p=int(cash[i,first[2]])+(second_yen//100)*int(cash[i,second[2]])
        row={'raceId':str(races[i]['id']),'day':str(races[i]['day']),
             'venue':str(races[i]['venue']),'year':int(year[i]),
             'quarter':int(quarter[i]),'market1':first[1],'ticket1':first[2],
             'market2':second[1],'ticket2':second[2],
             'stake1Yen':100,'stake2Yen':second_yen,
             'stakeYen':100+second_yen,'paidYen':p,
             'cashRuleScore':round(first[0]+second[0],7)}
        days[(row['day'],row['venue'])].append(row)
    result=[];count=Counter()
    for rows in days.values():
        chosen=sorted(rows,key=lambda x:(-x['cashRuleScore'],x['raceId']))[:5]
        count[len(chosen)]+=1;result.extend(chosen)
    if len({r['raceId'] for r in result})!=len(result):raise RuntimeError('DUPLICATE_RACE')
    coverage={'observedVenueDays':len(days),
              'selectedFiveVenueDays':count[5],
              'selectedThreeToFiveVenueDays':sum(v for k,v in count.items() if 3<=k<=5),
              'underThreeVenueDays':sum(v for k,v in count.items() if k<3),
              'allJraOfficialDaysIndependentlyVerified':False}
    return result,coverage

def main():
    if '--self-test' in sys.argv:
        assert EXPECTED==60969792
        assert metrics([dict(stakeYen=200,paidYen=500),dict(stakeYen=200,paidYen=100)])['minusLargestRaceCashRoiPct']==25
        assert len(CONTEXT)==5
        print('SIXTY_MILLION_DIRECT_CASH_SELFTEST_OK',flush=True);return
    start=time.monotonic()
    data,_=load_data()
    races,payout,cat,widths,types,rid,year,quarter,joint=data
    if len(races)<16000 or len(payout)!=336*len(races):raise RuntimeError('INVALID_CASH_UNIVERSE')
    features,encoded,definition=source_codes(data)
    scratch=ROOT/'analysis-results/nov2026-millions-cash-temporary.bin'
    print('CONDITION_UNIVERSE',json.dumps({'binaryFeatureCount':len(features),
          'allMarkets':6,'everyRuleLength':list(range(1,7)),
          'exhaustivelyScoredConjunctions':EXPECTED,
          'hypotheticalTickets':dump_matrix(data,encoded,scratch),
          'predictionLabelsUsed':False}),flush=True)
    try:
        audit,rules=run_miner(scratch)
    finally:
        scratch.unlink(missing_ok=True)
    if len(rules)<100:raise RuntimeError('TOO_FEW_FINANCIAL_CANDIDATES')
    RULES.parent.mkdir(parents=True,exist_ok=True)
    with gzip.open(RULES,'wt',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rules[0]));w.writeheader();w.writerows(rules)
    # Restrict PORTFOLIO selection to the 2022 historical cash, never 2023+.
    year_indices={y:np.flatnonzero(year==y) for y in (2022,2023,2024,2025,2026)}
    portfolio_scores={}
    # 2022 outcome is used to select the fixed combination of shortlists,
    # not to discover any rule beyond the earlier objective.
    for target in (2022,2023,2024,2025,2026):
        portfolio_scores[target]=build_scores(encoded,year_indices[target],rules)
    candidates=[]
    for k in TOPK:
        for mode in SCORE_MODES:
            for stake in STAKES:
                bets,cov=make_bets(data,year_indices[2022],portfolio_scores[2022][k][mode],stake)
                v=metrics(bets)
                # Independent held-out cash is never consulted to select.
                qual=(v['minusLargestRaceCashRoiPct'] or 0)
                if (v['hitRacePct'] or 0)<20:qual-=100
                candidates.append((qual,(v['minusLargestRaceCashRoiPct'] or 0),k,mode,stake,v))
    best=max(candidates,key=lambda x:(x[0],x[1],-x[2],-x[4]))
    _,_,k,mode,stake,validation=best
    print('CASH_SELECTION_FIXED_PRE2023',json.dumps({'topK':k,'scoreMode':mode,
          'secondaryStakeYen':stake,'year2022':validation}),flush=True)
    yearly={};coverage={};out=[]
    for y in (2023,2024,2025,2026):
        chosen,cov=make_bets(data,year_indices[y],portfolio_scores[y][k][mode],stake)
        yearly[str(y)]=metrics(chosen);coverage[str(y)]=cov
        out+=chosen
        print('FINANCIAL_MILLIONS_YEAR',y,json.dumps(yearly[str(y)]),flush=True)
    final=metrics(out)
    pass_cash=(final['minusLargestRaceCashRoiPct'] is not None
       and final['minusLargestRaceCashRoiPct']>=200
       and final['hitRacePct']>=20
       and all(yearly[str(y)]['minusLargestRaceCashRoiPct']>=200 for y in (2023,2024,2025,2026))
       and all(v['underThreeVenueDays']==0 for v in coverage.values()))
    report={'researchOnly':True,'candidateConditionsExactlyScored':sum(v['examined'] for v in audit),
      'cashPositiveTrainAnd2022Conditions':sum(v['positiveCashBoth'] for v in audit),
      'allScannedUsingReal100YenPaid':True,
      'binaryPredicateSearchDepth':DEPTH,'binaryFeatures':definition,
      'historicallySupportedRulesRetainedForPortfolio':len(rules),
      'sixMarketAudits':audit,
      'trainingYears':[2017,2018,2019,2020,2021],
      'portfolioChoiceOnlyYear':2022,
      'portfolioVariantsAfterExhaustiveCashRuleMining':len(candidates),
      'selectedUsingOnly2022Payout':{'topKPerMarket':k,'aggregate':mode,
                'secondTicketStakeYen':stake,'2022Cash':validation},
      'yearly':yearly,'combined':final,'venueDayCoverage':coverage,
      'passesHistoricalCashGate':bool(pass_cash),
      'adoptable':False,
      'adoptionBlockedBy':['Independent JRA payouts not reconciled',
         'Historical official JRA odds at T-minus-15 not available',
         '2025-2026 retrospective exposure to previous experiments',
         'Independently verified official venue day coverage unavailable'],
      'historicalPaidData':'third-party 100-yen actual settled payout mirror',
      'noProductionD1WorkersWrites':True,'elapsedSeconds':round(time.monotonic()-start,2)}
    OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    with gzip.open(BETS,'wt',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    print('FINANCIAL_MILLIONS_CASH_FINAL',json.dumps({'count':report['candidateConditionsExactlyScored'],
      'supportedConditions':report['cashPositiveTrainAnd2022Conditions'],
      'selected':report['selectedUsingOnly2022Payout'],
      'combined':final,'yearly':yearly,'cashGate':bool(pass_cash),
      'seconds':report['elapsedSeconds']}),flush=True)

if __name__=='__main__':main()
